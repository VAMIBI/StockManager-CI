package com.stockmanager.utils;

import com.stockmanager.model.Produit;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import java.awt.Color;

public class ExportUtil {
    public static void exporterProduitsPDF(List<Produit> produits, File fichier) throws Exception {
        Document document = new Document();

        try {
            PdfWriter.getInstance(document, new FileOutputStream(fichier));
            document.open();

            Font titreFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16);
            Font texteFont = FontFactory.getFont(FontFactory.HELVETICA, 11);
            Font enteteFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 11, Color.WHITE);

            Paragraph titre = new Paragraph("LISTE DES PRODUITS - STOCK MANAGER CI", titreFont);
            titre.setAlignment(com.lowagie.text.Element.ALIGN_CENTER);
            titre.setSpacingAfter(10);
            document.add(titre);

            Paragraph dateExport = new Paragraph("Date d'export : " + java.time.LocalDate.now(), texteFont);
            dateExport.setAlignment(com.lowagie.text.Element.ALIGN_CENTER);
            dateExport.setSpacingAfter(10);
            document.add(dateExport);

            PdfPTable table = new PdfPTable(7);
            table.setWidthPercentage(100);

            String[] entetes = {"Référence", "Désignation", "Prix", "Quantité", "Stock Min", "Unité", "Alerte"};

            for (String entete : entetes) {
                PdfPCell cell = new PdfPCell(new Phrase(entete, enteteFont));
                cell.setBackgroundColor(new Color(0, 102, 204));
                cell.setPadding(5);
                table.addCell(cell);
            }

            for (Produit p : produits) {
                boolean enAlerte = p.getQuantiteStock() <= p.getStockMinimum();

                Color couleurLigne = enAlerte ? new Color(255, 204, 204) : Color.WHITE;

                PdfPCell c1 = new PdfPCell(new Phrase(p.getReference(), texteFont));
                PdfPCell c2 = new PdfPCell(new Phrase(p.getDesignation(), texteFont));
                PdfPCell c3 = new PdfPCell(new Phrase(String.valueOf(p.getPrixUnitaire()), texteFont));
                PdfPCell c4 = new PdfPCell(new Phrase(String.valueOf(p.getQuantiteStock()), texteFont));
                PdfPCell c5 = new PdfPCell(new Phrase(String.valueOf(p.getStockMinimum()), texteFont));
                PdfPCell c6 = new PdfPCell(new Phrase(p.getUnite(), texteFont));
                PdfPCell c7 = new PdfPCell(new Phrase(enAlerte ? "OUI" : "NON", texteFont));

                PdfPCell[] cellules = {c1, c2, c3, c4, c5, c6, c7};

                for (PdfPCell cell : cellules) {
                    cell.setBackgroundColor(couleurLigne);
                    cell.setPadding(5);
                    table.addCell(cell);
                }
            }

            document.add(table);

        } catch (DocumentException e) {
            throw new Exception("Erreur lors de la création du PDF", e);
        } finally {
            document.close();
        }
    }
    public static void exporterProduitsXLSX(List<Produit> produits, File fichier) throws Exception {
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Produits");

            // Style entête
            CellStyle styleEntete = workbook.createCellStyle();
            org.apache.poi.ss.usermodel.Font fontEntete = workbook.createFont();
            fontEntete.setBold(true);
            fontEntete.setColor(IndexedColors.WHITE.getIndex());
            styleEntete.setFont(fontEntete);
            styleEntete.setFillForegroundColor(IndexedColors.BLUE.getIndex());
            styleEntete.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // Style alerte
            CellStyle styleAlerte = workbook.createCellStyle();
            styleAlerte.setFillForegroundColor(IndexedColors.ROSE.getIndex());
            styleAlerte.setFillPattern(FillPatternType.SOLID_FOREGROUND);

            // Entêtes
            String[] entetes = {
                    "Référence", "Désignation", "Prix (FCFA)",
                    "Quantité", "Stock Min", "Unité", "Alerte"
            };

            Row ligneEntete = sheet.createRow(0);
            for (int i = 0; i < entetes.length; i++) {
                Cell cell = ligneEntete.createCell(i);
                cell.setCellValue(entetes[i]);
                cell.setCellStyle(styleEntete);
            }

            // Données
            int numLigne = 1;
            for (Produit p : produits) {
                Row row = sheet.createRow(numLigne++);

                boolean enAlerte = p.getQuantiteStock() <= p.getStockMinimum();

                row.createCell(0).setCellValue(p.getReference());
                row.createCell(1).setCellValue(p.getDesignation());
                row.createCell(2).setCellValue(p.getPrixUnitaire());
                row.createCell(3).setCellValue(p.getQuantiteStock());
                row.createCell(4).setCellValue(p.getStockMinimum());
                row.createCell(5).setCellValue(p.getUnite());
                row.createCell(6).setCellValue(enAlerte ? "OUI" : "NON");

                if (enAlerte) {
                    for (int i = 0; i <= 6; i++) {
                        row.getCell(i).setCellStyle(styleAlerte);
                    }
                }
            }

            // Ajuster largeur
            for (int i = 0; i < entetes.length; i++) {
                sheet.autoSizeColumn(i);
            }

            // Sauvegarde
            try (FileOutputStream fos = new FileOutputStream(fichier)) {
                workbook.write(fos);
            }
        }
    }
}
