package com.stockmanager.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/stockmanager_ci";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public static Connection getConnection() {
        try {
            Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Connexion reussie a MySQL !");
            return connection;
        } catch (SQLException e) {
            System.out.println("Erreur de connexion a MySQL !");
            e.printStackTrace();
            return null;
        }
    }
}