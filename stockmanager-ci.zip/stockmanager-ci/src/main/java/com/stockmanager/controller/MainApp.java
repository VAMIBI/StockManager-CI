package com.stockmanager.controller;
import com.stockmanager.dao.FournisseurDAO;
import com.stockmanager.model.Fournisseur;
import com.stockmanager.dao.ProduitDAO;
import com.stockmanager.model.Produit;
import com.stockmanager.utils.DatabaseConnection;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.control.TableRow;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import com.stockmanager.dao.MouvementDAO;
import com.stockmanager.model.Mouvement;
import javafx.collections.FXCollections;
import javafx.scene.control.ComboBox;
import javafx.util.StringConverter;
import javafx.collections.ObservableList;
import javafx.scene.layout.HBox;
import javafx.geometry.Pos;
import javafx.animation.PauseTransition;
import javafx.scene.control.PasswordField;
import javafx.scene.layout.StackPane;
import javafx.util.Duration;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.math.BigInteger;
import java.security.MessageDigest;
import javafx.scene.text.TextAlignment;
import javafx.scene.layout.VBox;
import javafx.scene.control.ProgressBar;
import com.stockmanager.utils.ExportUtil;
import javafx.scene.control.Alert;
import javafx.stage.FileChooser;
import java.io.File;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;


public class MainApp extends Application {

    private String sha256(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(input.getBytes());

            StringBuilder hexString = new StringBuilder();

            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }

            return hexString.toString();

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


    @Override
    public void start(Stage stage) {
        afficherSplash(stage);
    }
    private void afficherSplash(Stage stage) {
        stage.setResizable(false);
        VBox root = new VBox(20);
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-background-color: #1E3A8A;");

        Label title = new Label("Projet Fin module : StockManager CI");
        title.setStyle("-fx-text-fill: white; -fx-font-size: 21px; -fx-font-weight: bold;");

        Label subtitle = new Label("Application réalisée par VAMI BI et AGNIMAN BOMO");
        subtitle.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");

        ProgressBar progressBar = new ProgressBar();
        progressBar.setPrefWidth(300);

        root.getChildren().addAll(title, subtitle, progressBar);

        Scene scene = new Scene(root, 500, 300);
        stage.setScene(scene);
        stage.setTitle("Démarrage");
        stage.show();

        PauseTransition pause = new PauseTransition(Duration.seconds(2));
        pause.setOnFinished(e -> afficherLogin(stage));
        pause.play();
    }
    private void afficherLogin(Stage stage) {
        Label lblTitre = new Label("Connexion");
        lblTitre.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        Label lblUser = new Label("Login :");
        TextField txtUser = new TextField();

        Label lblPass = new Label("Mot de passe :");
        PasswordField txtPass = new PasswordField();

        Button btnLogin = new Button("Se connecter");
        Label lblMessage = new Label();

        VBox root = new VBox(10, lblTitre, lblUser, txtUser, lblPass, txtPass, btnLogin, lblMessage);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        btnLogin.setOnAction(e -> {

            System.out.println("=== CLICK ===");

            String login = txtUser.getText().trim();
            String motDePasse = txtPass.getText().trim();

            System.out.println("Login saisi : " + login);

            try {
                System.out.println("Avant connexion DB");

                Connection conn = DatabaseConnection.getConnection();

                System.out.println("Connexion DB OK");

                String sql = "SELECT * FROM utilisateurs WHERE login = ? AND actif = 1";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, login);

                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    System.out.println("Utilisateur trouvé");

                    String motDePasseBD = rs.getString("mot_de_passe");
                    String role = rs.getString("role");

                    String hash = sha256(motDePasse);

                    if (hash.equalsIgnoreCase(motDePasseBD)) {
                        System.out.println("Mot de passe OK");

                        System.out.println("Avant ouverture fenêtre");
                        ouvrirApplication(stage, role);
                        System.out.println("Après ouverture fenêtre");

                    } else {
                        System.out.println("Mot de passe incorrect");
                        lblMessage.setText("Mot de passe incorrect");
                    }

                } else {
                    System.out.println("Utilisateur non trouvé");
                    lblMessage.setText("Utilisateur introuvable");
                }

            } catch (Exception ex) {
                ex.printStackTrace();
                lblMessage.setText("Erreur : " + ex.getMessage());
            }
        });
        Scene scene = new Scene(root, 350, 250);
        stage.setScene(scene);
        stage.setTitle("Connexion - StockManager CI");
        stage.show();
    }
    private void ouvrirApplication(Stage stage, String role) {
        try {
            System.out.println("=== Entrée dans ouvrirApplication ===");
            System.out.println("Role reçu : " + role);

            ProduitDAO produitDAO = new ProduitDAO();
            FournisseurDAO fournisseurDAO = new FournisseurDAO();
            MouvementDAO mouvementDAO = new MouvementDAO();

            // ================= DASHBOARD DYNAMIQUE =================
            Label valeurProduits = new Label();
            valeurProduits.setStyle("-fx-text-fill: white; -fx-font-size: 22px; -fx-font-weight: bold;");

            Label valeurFournisseurs = new Label();
            valeurFournisseurs.setStyle("-fx-text-fill: white; -fx-font-size: 22px; -fx-font-weight: bold;");

            Label valeurMouvements = new Label();
            valeurMouvements.setStyle("-fx-text-fill: white; -fx-font-size: 22px; -fx-font-weight: bold;");

            Label valeurStock = new Label();
            valeurStock.setStyle("-fx-text-fill: white; -fx-font-size: 22px; -fx-font-weight: bold;");

            Label titreProduits = new Label("Produits");
            titreProduits.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");

            VBox cardProduits = new VBox(8, titreProduits, valeurProduits);
            cardProduits.setPrefWidth(150);
            cardProduits.setMinHeight(90);
            cardProduits.setAlignment(Pos.CENTER);
            cardProduits.setStyle("-fx-background-color: #2ecc71; -fx-padding: 15; -fx-background-radius: 10;");

            Label titreFournisseurs = new Label("Fournisseurs");
            titreFournisseurs.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");

            VBox cardFournisseurs = new VBox(8, titreFournisseurs, valeurFournisseurs);
            cardFournisseurs.setPrefWidth(150);
            cardFournisseurs.setMinHeight(90);
            cardFournisseurs.setAlignment(Pos.CENTER);
            cardFournisseurs.setStyle("-fx-background-color: #3498db; -fx-padding: 15; -fx-background-radius: 10;");

            Label titreMouvements = new Label("Mouvements");
            titreMouvements.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");

            VBox cardMouvements = new VBox(8, titreMouvements, valeurMouvements);
            cardMouvements.setPrefWidth(150);
            cardMouvements.setMinHeight(90);
            cardMouvements.setAlignment(Pos.CENTER);
            cardMouvements.setStyle("-fx-background-color: #9b59b6; -fx-padding: 15; -fx-background-radius: 10;");

            Label titreStock = new Label("Stock critique");
            titreStock.setStyle("-fx-text-fill: white; -fx-font-size: 14px;");

            VBox cardStock = new VBox(8, titreStock, valeurStock);
            cardStock.setPrefWidth(150);
            cardStock.setMinHeight(90);
            cardStock.setAlignment(Pos.CENTER);
            cardStock.setStyle("-fx-background-color: #e74c3c; -fx-padding: 15; -fx-background-radius: 10;");

            CategoryAxis xAxis = new CategoryAxis();
            xAxis.setLabel("Catégories");

            NumberAxis yAxis = new NumberAxis();
            yAxis.setLabel("Nombre");

            BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
            barChart.setTitle("Statistiques du stock");
            barChart.setLegendVisible(false);
            barChart.setPrefHeight(180);

            XYChart.Series<String, Number> series = new XYChart.Series<>();
            barChart.getData().add(series);

            HBox dashboardBox = new HBox(20, cardProduits, cardFournisseurs, cardMouvements, cardStock);
            dashboardBox.setPadding(new Insets(10));
            dashboardBox.setAlignment(Pos.CENTER);

            Runnable refreshDashboard = () -> {
                int nbProduits = produitDAO.countProduits();
                int nbFournisseurs = fournisseurDAO.countFournisseurs();
                int nbMouvements = mouvementDAO.countMouvements();
                int nbStockCritique = produitDAO.countStockCritique();

                valeurProduits.setText(String.valueOf(nbProduits));
                valeurFournisseurs.setText(String.valueOf(nbFournisseurs));
                valeurMouvements.setText(String.valueOf(nbMouvements));
                valeurStock.setText(String.valueOf(nbStockCritique));

                series.getData().clear();
                series.getData().add(new XYChart.Data<>("Produits", nbProduits));
                series.getData().add(new XYChart.Data<>("Fournisseurs", nbFournisseurs));
                series.getData().add(new XYChart.Data<>("Mouvements", nbMouvements));
                series.getData().add(new XYChart.Data<>("Stock critique", nbStockCritique));
            };

            refreshDashboard.run();
            // ======================================================

            final int[] selectedId = {0};
            final int[] pageCourante = {1};
            final int taillePage = 15;
            Label lblPage = new Label();

            TableView<Produit> tableView = new TableView<>();
            tableView.setPrefHeight(300);
            VBox.setVgrow(tableView, Priority.ALWAYS);

            tableView.setRowFactory(tv -> new TableRow<Produit>() {
                @Override
                protected void updateItem(Produit produit, boolean empty) {
                    super.updateItem(produit, empty);

                    if (produit == null || empty) {
                        setStyle("");
                    } else if (produit.getQuantiteStock() <= produit.getStockMinimum()) {
                        setStyle("-fx-background-color: #ffcccc;");
                    } else {
                        setStyle("");
                    }
                }
            });

            TableColumn<Produit, String> colId = new TableColumn<>("ID");
            colId.setCellValueFactory(data ->
                    new SimpleStringProperty(String.valueOf(data.getValue().getId()))
            );

            TableColumn<Produit, String> colReference = new TableColumn<>("Reference");
            colReference.setCellValueFactory(data ->
                    new SimpleStringProperty(data.getValue().getReference())
            );

            TableColumn<Produit, String> colDesignation = new TableColumn<>("Designation");
            colDesignation.setCellValueFactory(data ->
                    new SimpleStringProperty(data.getValue().getDesignation())
            );

            TableColumn<Produit, String> colPrix = new TableColumn<>("Prix");
            colPrix.setCellValueFactory(data ->
                    new SimpleStringProperty(String.valueOf(data.getValue().getPrixUnitaire()))
            );

            TableColumn<Produit, String> colQuantite = new TableColumn<>("Quantite");
            colQuantite.setCellValueFactory(data ->
                    new SimpleStringProperty(String.valueOf(data.getValue().getQuantiteStock()))
            );

            TableColumn<Produit, String> colStockMin = new TableColumn<>("Stock Min");
            colStockMin.setCellValueFactory(data ->
                    new SimpleStringProperty(String.valueOf(data.getValue().getStockMinimum()))
            );

            TableColumn<Produit, String> colUnite = new TableColumn<>("Unite");
            colUnite.setCellValueFactory(data ->
                    new SimpleStringProperty(data.getValue().getUnite())
            );

            tableView.getColumns().addAll(
                    colId, colReference, colDesignation, colPrix, colQuantite, colStockMin, colUnite
            );

            Runnable chargerPageProduits = () -> {
                int offset = (pageCourante[0] - 1) * taillePage;
                tableView.getItems().setAll(produitDAO.getProduitsParPage(taillePage, offset));

                int total = produitDAO.countProduits();
                int totalPages = (int) Math.ceil((double) total / taillePage);

                if (totalPages == 0) {
                    totalPages = 1;
                }

                lblPage.setText("Page " + pageCourante[0] + " / " + totalPages + " — " + total + " produits");
            };

            Button btnPrecedent = new Button("Précédent");
            Button btnSuivant = new Button("Suivant");

            btnPrecedent.setOnAction(e -> {
                if (pageCourante[0] > 1) {
                    pageCourante[0]--;
                    chargerPageProduits.run();
                }
            });

            btnSuivant.setOnAction(e -> {
                int total = produitDAO.countProduits();
                int totalPages = (int) Math.ceil((double) total / taillePage);

                if (pageCourante[0] < totalPages) {
                    pageCourante[0]++;
                    chargerPageProduits.run();
                }
            });

            TextField txtReference = new TextField();
            TextField txtDesignation = new TextField();
            TextField txtPrix = new TextField();
            TextField txtQuantite = new TextField();
            TextField txtStockMin = new TextField();
            TextField txtUnite = new TextField();

            tableView.setOnMouseClicked(e -> {
                Produit p = tableView.getSelectionModel().getSelectedItem();

                if (p != null) {
                    selectedId[0] = p.getId();
                    txtReference.setText(p.getReference());
                    txtDesignation.setText(p.getDesignation());
                    txtPrix.setText(String.valueOf(p.getPrixUnitaire()));
                    txtQuantite.setText(String.valueOf(p.getQuantiteStock()));
                    txtStockMin.setText(String.valueOf(p.getStockMinimum()));
                    txtUnite.setText(p.getUnite());
                }
            });

            GridPane form = new GridPane();
            form.setHgap(10);
            form.setVgap(10);
            form.setPadding(new Insets(10));

            form.add(new Label("Reference :"), 0, 0);
            form.add(txtReference, 1, 0);

            form.add(new Label("Designation :"), 0, 1);
            form.add(txtDesignation, 1, 1);

            form.add(new Label("Prix :"), 0, 2);
            form.add(txtPrix, 1, 2);

            form.add(new Label("Quantite :"), 0, 3);
            form.add(txtQuantite, 1, 3);

            form.add(new Label("Stock Min :"), 0, 4);
            form.add(txtStockMin, 1, 4);

            form.add(new Label("Unite :"), 0, 5);
            form.add(txtUnite, 1, 5);

            Button btnSupprimer = new Button("Supprimer");
            Button btnAjouter = new Button("Ajouter");
            Button btnActualiser = new Button("Actualiser");
            Button btnModifier = new Button("Modifier");
            Button btnExporter = new Button("Exporter Excel");
            Button btnExporterPDF = new Button("Exporter PDF");

            btnSupprimer.setOnAction(e -> {
                Produit selected = tableView.getSelectionModel().getSelectedItem();

                if (selected != null) {
                    produitDAO.deleteProduit(selected.getId());
                    chargerPageProduits.run();
                    refreshDashboard.run();
                } else {
                    System.out.println("Selectionnez une ligne !");
                }
            });

            btnAjouter.setOnAction(e -> {
                try {
                    Produit produit = new Produit(
                            0,
                            txtReference.getText(),
                            txtDesignation.getText(),
                            Double.parseDouble(txtPrix.getText()),
                            Integer.parseInt(txtQuantite.getText()),
                            Integer.parseInt(txtStockMin.getText()),
                            txtUnite.getText()
                    );

                    produitDAO.ajouterProduit(produit);
                    chargerPageProduits.run();
                    refreshDashboard.run();

                    txtReference.clear();
                    txtDesignation.clear();
                    txtPrix.clear();
                    txtQuantite.clear();
                    txtStockMin.clear();
                    txtUnite.clear();

                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            });

            btnActualiser.setOnAction(e -> {
                tableView.getItems().setAll(produitDAO.getAllProduits());
                refreshDashboard.run();
            });

            btnModifier.setOnAction(e -> {
                if (selectedId[0] != 0) {
                    try {
                        Produit produit = new Produit(
                                selectedId[0],
                                txtReference.getText(),
                                txtDesignation.getText(),
                                Double.parseDouble(txtPrix.getText()),
                                Integer.parseInt(txtQuantite.getText()),
                                Integer.parseInt(txtStockMin.getText()),
                                txtUnite.getText()
                        );

                        produitDAO.updateProduit(produit);
                        chargerPageProduits.run();
                        refreshDashboard.run();

                        System.out.println("Produit modifié avec succès !");

                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                } else {
                    System.out.println("Selectionnez un produit !");
                }
            });

            btnExporterPDF.setOnAction(e -> {
                try {
                    FileChooser fileChooser = new FileChooser();
                    fileChooser.setTitle("Enregistrer le fichier PDF");
                    fileChooser.getExtensionFilters().add(
                            new FileChooser.ExtensionFilter("Fichier PDF", "*.pdf")
                    );
                    fileChooser.setInitialFileName("produits.pdf");

                    File fichier = fileChooser.showSaveDialog(stage);

                    if (fichier != null) {
                        ExportUtil.exporterProduitsPDF(produitDAO.getAllProduits(), fichier);

                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Export PDF réussi");
                        alert.setHeaderText(null);
                        alert.setContentText("Fichier PDF exporté avec succès :\n" + fichier.getAbsolutePath());
                        alert.showAndWait();
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();

                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Erreur");
                    alert.setHeaderText(null);
                    alert.setContentText("Erreur lors de l'export PDF.");
                    alert.showAndWait();
                }
            });

            btnExporter.setOnAction(e -> {
                try {
                    FileChooser fileChooser = new FileChooser();
                    fileChooser.setTitle("Enregistrer le fichier Excel");
                    fileChooser.getExtensionFilters().add(
                            new FileChooser.ExtensionFilter("Fichier Excel", "*.xlsx")
                    );
                    fileChooser.setInitialFileName("produits.xlsx");

                    File fichier = fileChooser.showSaveDialog(stage);

                    if (fichier != null) {
                        ExportUtil.exporterProduitsXLSX(produitDAO.getAllProduits(), fichier);

                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Export réussi");
                        alert.setHeaderText(null);
                        alert.setContentText("Fichier exporté avec succès :\n" + fichier.getAbsolutePath());
                        alert.showAndWait();
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();

                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Erreur");
                    alert.setHeaderText(null);
                    alert.setContentText("Erreur lors de l'export Excel.");
                    alert.showAndWait();
                }
            });

            if (!role.equalsIgnoreCase("ADMIN")) {
                btnAjouter.setDisable(true);
                btnModifier.setDisable(true);
                btnSupprimer.setDisable(true);
                btnExporter.setDisable(true);
                btnExporterPDF.setDisable(true);

                txtReference.setDisable(true);
                txtDesignation.setDisable(true);
                txtPrix.setDisable(true);
                txtQuantite.setDisable(true);
                txtStockMin.setDisable(true);
                txtUnite.setDisable(true);
            }

            chargerPageProduits.run();

            // ================= FOURNISSEURS =================
            TextField txtNomF = new TextField();
            TextField txtTelF = new TextField();
            TextField txtEmailF = new TextField();
            TextField txtAdresseF = new TextField();
            TextField txtVilleF = new TextField();

            GridPane formF = new GridPane();
            formF.setHgap(10);
            formF.setVgap(10);
            formF.setPadding(new Insets(10));

            formF.add(new Label("Nom :"), 0, 0);
            formF.add(txtNomF, 1, 0);

            formF.add(new Label("Téléphone :"), 0, 1);
            formF.add(txtTelF, 1, 1);

            formF.add(new Label("Email :"), 0, 2);
            formF.add(txtEmailF, 1, 2);

            formF.add(new Label("Adresse :"), 0, 3);
            formF.add(txtAdresseF, 1, 3);

            formF.add(new Label("Ville :"), 0, 4);
            formF.add(txtVilleF, 1, 4);

            TableView<Fournisseur> tableF = new TableView<>();

            TableColumn<Fournisseur, String> colNomF = new TableColumn<>("Nom");
            colNomF.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getNom()));

            TableColumn<Fournisseur, String> colTelF = new TableColumn<>("Téléphone");
            colTelF.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getTelephone()));

            TableColumn<Fournisseur, String> colEmailF = new TableColumn<>("Email");
            colEmailF.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getEmail()));

            TableColumn<Fournisseur, String> colVilleF = new TableColumn<>("Ville");
            colVilleF.setCellValueFactory(data -> new SimpleStringProperty(data.getValue().getVille()));

            tableF.getColumns().addAll(colNomF, colTelF, colEmailF, colVilleF);

            Button btnAjouterF = new Button("Ajouter Fournisseur");
            Button btnActualiserF = new Button("Actualiser Fournisseurs");

            btnAjouterF.setOnAction(e -> {
                Fournisseur f = new Fournisseur(
                        txtNomF.getText(),
                        txtTelF.getText(),
                        txtEmailF.getText(),
                        txtAdresseF.getText(),
                        txtVilleF.getText()
                );

                fournisseurDAO.ajouter(f);
                tableF.getItems().setAll(fournisseurDAO.getAll());
                refreshDashboard.run();

                txtNomF.clear();
                txtTelF.clear();
                txtEmailF.clear();
                txtAdresseF.clear();
                txtVilleF.clear();
            });

            btnActualiserF.setOnAction(e -> {
                tableF.getItems().setAll(fournisseurDAO.getAll());
                refreshDashboard.run();
            });

            tableF.getItems().setAll(fournisseurDAO.getAll());

            VBox fournisseurBox = new VBox(10, formF, btnAjouterF, btnActualiserF, tableF);
            fournisseurBox.setPadding(new Insets(10));

            // ================= PRODUITS =================
            HBox paginationBox = new HBox(10, lblPage, btnPrecedent, btnSuivant);
            paginationBox.setAlignment(Pos.CENTER_LEFT);

            HBox actionsBox = new HBox(10, btnAjouter, btnModifier, btnActualiser, btnSupprimer, btnExporter, btnExporterPDF);
            actionsBox.setAlignment(Pos.CENTER_LEFT);

            Label lblRole = new Label("Connecté en tant que : " + role);
            lblRole.setStyle("-fx-font-size: 14px; -fx-font-weight: bold;");

            VBox root = new VBox(
                    10,
                    lblRole,
                    dashboardBox,
                    barChart,
                    form,
                    actionsBox,
                    paginationBox,
                    tableView
            );
            root.setPadding(new Insets(10));

            ScrollPane scrollPane = new ScrollPane(root);
            scrollPane.setFitToWidth(true);

            // ================= MOUVEMENTS =================
            ComboBox<Produit> comboProduit = new ComboBox<>();
            comboProduit.getItems().addAll(produitDAO.getAllProduits());

            comboProduit.setConverter(new StringConverter<Produit>() {
                @Override
                public String toString(Produit p) {
                    return p != null ? p.getDesignation() : "";
                }

                @Override
                public Produit fromString(String string) {
                    return null;
                }
            });

            TextField txtQuantiteM = new TextField();

            Button btnEntree = new Button("Entrée Stock");
            Button btnSortie = new Button("Sortie Stock");

            TableView<Mouvement> tableM = new TableView<>();

            TableColumn<Mouvement, String> colProduit = new TableColumn<>("Produit");
            colProduit.setCellValueFactory(data ->
                    new SimpleStringProperty(String.valueOf(data.getValue().getProduitId()))
            );

            TableColumn<Mouvement, String> colType = new TableColumn<>("Type");
            colType.setCellValueFactory(data ->
                    new SimpleStringProperty(data.getValue().getType())
            );

            TableColumn<Mouvement, String> colQuantiteM = new TableColumn<>("Quantité");
            colQuantiteM.setCellValueFactory(data ->
                    new SimpleStringProperty(String.valueOf(data.getValue().getQuantite()))
            );

            tableM.getColumns().addAll(colProduit, colType, colQuantiteM);

            ObservableList<Mouvement> listeMouvements = FXCollections.observableArrayList();
            for (Mouvement mvt : mouvementDAO.getAll()) {
                listeMouvements.add(mvt);
            }
            tableM.setItems(listeMouvements);

            Button btnRefreshM = new Button("Actualiser Historique");
            btnRefreshM.setOnAction(e -> {
                ObservableList<Mouvement> listeRefresh = FXCollections.observableArrayList();
                for (Mouvement mvt : mouvementDAO.getAll()) {
                    listeRefresh.add(mvt);
                }
                tableM.setItems(listeRefresh);
                refreshDashboard.run();
            });

            btnEntree.setOnAction(e -> {
                Produit p = comboProduit.getValue();

                if (p != null) {
                    Mouvement m = new Mouvement(
                            p.getId(),
                            "ENTREE",
                            Integer.parseInt(txtQuantiteM.getText())
                    );

                    mouvementDAO.effectuerMouvement(m);
                    chargerPageProduits.run();
                    refreshDashboard.run();

                    ObservableList<Mouvement> listeRefresh = FXCollections.observableArrayList();
                    for (Mouvement mvt : mouvementDAO.getAll()) {
                        listeRefresh.add(mvt);
                    }
                    tableM.setItems(listeRefresh);
                }
            });

            btnSortie.setOnAction(e -> {
                Produit p = comboProduit.getValue();

                if (p != null) {
                    Mouvement m = new Mouvement(
                            p.getId(),
                            "SORTIE",
                            Integer.parseInt(txtQuantiteM.getText())
                    );

                    mouvementDAO.effectuerMouvement(m);
                    chargerPageProduits.run();
                    refreshDashboard.run();

                    ObservableList<Mouvement> listeRefresh = FXCollections.observableArrayList();
                    for (Mouvement mvt : mouvementDAO.getAll()) {
                        listeRefresh.add(mvt);
                    }
                    tableM.setItems(listeRefresh);
                }
            });

            VBox mouvementBox = new VBox(
                    10,
                    new Label("Produit"),
                    comboProduit,
                    new Label("Quantité"),
                    txtQuantiteM,
                    btnEntree,
                    btnSortie,
                    btnRefreshM,
                    tableM
            );
            mouvementBox.setPadding(new Insets(10));

            // ================= ONGLETS =================
            TabPane tabPane = new TabPane();

            Tab tabProduits = new Tab("Produits", scrollPane);
            tabProduits.setClosable(false);

            Tab tabFournisseurs = new Tab("Fournisseurs", fournisseurBox);
            tabFournisseurs.setClosable(false);

            Tab tabMouvements = new Tab("Mouvements", mouvementBox);
            tabMouvements.setClosable(false);

            tabPane.getTabs().addAll(tabProduits, tabFournisseurs, tabMouvements);

            Scene scene = new Scene(tabPane, 1000, 600);
            stage.setTitle("StockManager CI");
            stage.setScene(scene);
            stage.show();

            System.out.println("=== Fin normale de ouvrirApplication ===");

        } catch (Exception ex) {
            System.out.println("=== ERREUR DANS ouvrirApplication ===");
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch();
    }
}