package com.stockmanager.model;

public class Produit {
    private int id;
    private String reference;
    private String designation;
    private double prixUnitaire;
    private int quantiteStock;
    private int stockMinimum;
    private String unite;

    public Produit() {}

    public Produit(int id, String reference, String designation, double prixUnitaire,
                   int quantiteStock, int stockMinimum, String unite) {
        this.id = id;
        this.reference = reference;
        this.designation = designation;
        this.prixUnitaire = prixUnitaire;
        this.quantiteStock = quantiteStock;
        this.stockMinimum = stockMinimum;
        this.unite = unite;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getReference() { return reference; }
    public void setReference(String reference) { this.reference = reference; }

    public String getDesignation() { return designation; }
    public void setDesignation(String designation) { this.designation = designation; }

    public double getPrixUnitaire() { return prixUnitaire; }
    public void setPrixUnitaire(double prixUnitaire) { this.prixUnitaire = prixUnitaire; }

    public int getQuantiteStock() { return quantiteStock; }
    public void setQuantiteStock(int quantiteStock) { this.quantiteStock = quantiteStock; }

    public int getStockMinimum() { return stockMinimum; }
    public void setStockMinimum(int stockMinimum) { this.stockMinimum = stockMinimum; }

    public String getUnite() { return unite; }
    public void setUnite(String unite) { this.unite = unite; }
}
