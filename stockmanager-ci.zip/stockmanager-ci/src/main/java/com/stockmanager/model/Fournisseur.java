package com.stockmanager.model;

public class Fournisseur {
    private int id;
    private String nom;
    private String telephone;
    private String email;
    private String adresse;
    private String ville;

    public Fournisseur(int id, String nom, String telephone, String email, String adresse, String ville) {
        this.id = id;
        this.nom = nom;
        this.telephone = telephone;
        this.email = email;
        this.adresse = adresse;
        this.ville = ville;
    }

    public Fournisseur(String nom, String telephone, String email, String adresse, String ville) {
        this.nom = nom;
        this.telephone = telephone;
        this.email = email;
        this.adresse = adresse;
        this.ville = ville;
    }

    public int getId() { return id; }
    public String getNom() { return nom; }
    public String getTelephone() { return telephone; }
    public String getEmail() { return email; }
    public String getAdresse() { return adresse; }
    public String getVille() { return ville; }
}