package com.stockmanager.model;

import java.sql.Timestamp;

public class Mouvement {

    private int id;
    private int produitId;
    private String type; // ENTREE ou SORTIE
    private int quantite;
    private Timestamp date;

    public Mouvement(int produitId, String type, int quantite) {
        this.produitId = produitId;
        this.type = type;
        this.quantite = quantite;
    }

    public int getProduitId() { return produitId; }
    public String getType() { return type; }
    public int getQuantite() { return quantite; }
}