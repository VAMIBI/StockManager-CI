package com.stockmanager.dao;

import com.stockmanager.model.Fournisseur;
import com.stockmanager.utils.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class FournisseurDAO {

    public void ajouter(Fournisseur f) {
        String sql = "INSERT INTO fournisseurs(nom, telephone, email, adresse, ville) VALUES(?,?,?,?,?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, f.getNom());
            ps.setString(2, f.getTelephone());
            ps.setString(3, f.getEmail());
            ps.setString(4, f.getAdresse());
            ps.setString(5, f.getVille());

            ps.executeUpdate();
            System.out.println("Fournisseur ajoute avec succes !");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Fournisseur> getAll() {
        List<Fournisseur> list = new ArrayList<>();

        String sql = "SELECT * FROM fournisseurs";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                list.add(new Fournisseur(
                        rs.getInt("id"),
                        rs.getString("nom"),
                        rs.getString("telephone"),
                        rs.getString("email"),
                        rs.getString("adresse"),
                        rs.getString("ville")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    public int countFournisseurs() {
        String sql = "SELECT COUNT(*) FROM fournisseurs";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) return rs.getInt(1);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }
    public void supprimer(int id) {
        String sql = "DELETE FROM fournisseurs WHERE id=?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
            System.out.println("Fournisseur supprime avec succes !");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}