package com.stockmanager.dao;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.stockmanager.model.Produit;
import com.stockmanager.utils.DatabaseConnection;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ProduitDAO {


    public int countStockCritique() {
        String sql = "SELECT COUNT(*) FROM produits WHERE quantite_stock <= stock_minimum";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }



    public void ajouterProduit(Produit produit) {
        String sql = "INSERT INTO produits(reference, designation, id_categorie, id_fournisseur, prix_unitaire, quantite_stock, stock_minimum, unite) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        Connection conn = DatabaseConnection.getConnection();

        if (conn == null) {
            System.out.println("Connexion echouee !");
            return;
        }

        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, produit.getReference());
            ps.setString(2, produit.getDesignation());

// temporairement NULL (on fera après avec les catégories)
            ps.setNull(3, java.sql.Types.INTEGER);
            ps.setNull(4, java.sql.Types.INTEGER);

            ps.setDouble(5, produit.getPrixUnitaire());
            ps.setInt(6, produit.getQuantiteStock());
            ps.setInt(7, produit.getStockMinimum());
            ps.setString(8, produit.getUnite());

            ps.executeUpdate();
            System.out.println("Produit ajoute avec succes !");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public List<Produit> getAllProduits() {
        List<Produit> liste = new ArrayList<>();

        String sql = "SELECT * FROM produits";

        Connection conn = DatabaseConnection.getConnection();

        if (conn == null) {
            System.out.println("Connexion echouee !");
            return liste;
        }

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Produit p = new Produit(
                        rs.getInt("id"),
                        rs.getString("reference"),
                        rs.getString("designation"),
                        rs.getDouble("prix_unitaire"),
                        rs.getInt("quantite_stock"),
                        rs.getInt("stock_minimum"),
                        rs.getString("unite")
                );

                liste.add(p);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return liste;
    }
    public List<Produit> getProduitsParPage(int limit, int offset) {
        List<Produit> list = new ArrayList<>();

        String sql = "SELECT * FROM produits LIMIT ? OFFSET ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, limit);
            ps.setInt(2, offset);

            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                list.add(new Produit(
                        rs.getInt("id"),
                        rs.getString("reference"),
                        rs.getString("designation"),
                        rs.getDouble("prix_unitaire"),
                        rs.getInt("quantite_stock"),
                        rs.getInt("stock_minimum"),
                        rs.getString("unite")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    public int countProduits() {
        String sql = "SELECT COUNT(*) FROM produits";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }
    public void deleteProduit(int id) {
        String sql = "DELETE FROM produits WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("Produit supprime avec succes !");
            } else {
                System.out.println("Aucun produit trouve avec l'id : " + id);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void updateProduit(Produit produit) {
        String sql = "UPDATE produits SET reference=?, designation=?, prix_unitaire=?, quantite_stock=?, stock_minimum=?, unite=? WHERE id=?";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, produit.getReference());
            ps.setString(2, produit.getDesignation());
            ps.setDouble(3, produit.getPrixUnitaire());
            ps.setInt(4, produit.getQuantiteStock());
            ps.setInt(5, produit.getStockMinimum());
            ps.setString(6, produit.getUnite());
            ps.setInt(7, produit.getId());

            ps.executeUpdate();

            System.out.println("Produit modifie avec succes !");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}