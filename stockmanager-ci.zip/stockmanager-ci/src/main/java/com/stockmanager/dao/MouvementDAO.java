package com.stockmanager.dao;

import com.stockmanager.model.Mouvement;
import com.stockmanager.utils.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class MouvementDAO {

    public int countMouvements() {
        String sql = "SELECT COUNT(*) FROM mouvements";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) return rs.getInt(1);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return 0;
    }

    public void effectuerMouvement(Mouvement m) {

        String verifierStock = "SELECT quantite_stock FROM produits WHERE id = ?";
        String insert = "INSERT INTO mouvements(id_produit, type_mouvement, quantite) VALUES(?,?,?)";
        String updateEntree = "UPDATE produits SET quantite_stock = quantite_stock + ? WHERE id = ?";
        String updateSortie = "UPDATE produits SET quantite_stock = quantite_stock - ? WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection()) {

            // Vérifier le stock disponible en cas de sortie
            if (m.getType().equals("SORTIE")) {
                PreparedStatement psCheck = conn.prepareStatement(verifierStock);
                psCheck.setInt(1, m.getProduitId());
                ResultSet rs = psCheck.executeQuery();

                if (rs.next()) {
                    int stockActuel = rs.getInt("quantite_stock");

                    if (m.getQuantite() > stockActuel) {
                        System.out.println("Stock insuffisant !");
                        return;
                    }
                }
            }

            // 1. enregistrer le mouvement
            PreparedStatement ps = conn.prepareStatement(insert);
            ps.setInt(1, m.getProduitId());
            ps.setString(2, m.getType());
            ps.setInt(3, m.getQuantite());
            ps.executeUpdate();

            // 2. mettre à jour le stock
            PreparedStatement ps2;

            if (m.getType().equals("ENTREE")) {
                ps2 = conn.prepareStatement(updateEntree);
            } else {
                ps2 = conn.prepareStatement(updateSortie);
            }

            ps2.setInt(1, m.getQuantite());
            ps2.setInt(2, m.getProduitId());
            ps2.executeUpdate();

            System.out.println("Mouvement effectue avec succes !");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public List<Mouvement> getAll() {
        List<Mouvement> list = new ArrayList<>();

        String sql = "SELECT * FROM mouvements";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                list.add(new Mouvement(
                        rs.getInt("id_produit"),
                        rs.getString("type_mouvement"),
                        rs.getInt("quantite")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}