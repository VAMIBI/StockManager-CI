package com.stockmanager;

import com.stockmanager.dao.ProduitDAO;
import com.stockmanager.model.Produit;

public class TestConnexion {
    public static void main(String[] args) {
        ProduitDAO dao = new ProduitDAO();

        Produit produit = new Produit(
                0,
                "REF002",
                "Clavier",
                15000,
                20,
                5,
                "Piece"
        );

        dao.ajouterProduit(produit);
    }
}